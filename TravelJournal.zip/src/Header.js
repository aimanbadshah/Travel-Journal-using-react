import React from "react";
import Image from "./HeaderLogo.png";
import './index.css'; 

export default function Header() {
    return (
        <header className="header">
            <img src={Image} alt="header Logo" className="header-logo" />
            <h5 className="header-title">my travel journal.</h5>
        </header>
    );
}
