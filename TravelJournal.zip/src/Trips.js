import React from "react";
import Image from "./Location Icon.png";

export default function Trips(props) {
    return (
        <div className="page-container">
            <div className="card">
            <img src={`../images/${props.imageUrl}`} alt={props.title} className="card-img" />
            <div className="card-content">
                <div className="card-location">
                    <img src={Image} alt="Location Icon" style={{ height: '14px', margin: '15px 0 0 -10px' }} />
                    <span className="location">{props.location}</span>
                    <a href={props.googleMapsUrl} className="google-maps-link"> View on Google Maps</a>
                </div>
                <h2 className="card-title">{props.title}</h2>
                <p className="date-range">{props.startDate} - {props.endDate}</p>
                <p className="card-description">{props.description}</p>
            </div>
        </div>
        </div>
    );
}
