
// eslint-disable-next-line import/no-anonymous-default-export
export default [
    {
        id:(1),
        title: "Kalam",
        location: "Pakistan",
        googleMapsUrl: "https://maps.app.goo.gl/nk86QUkAzyPthoY29",
        startDate: "5 July, 2012",
        endDate: "15 July, 2012",
        description: "Kalam is a scenic town in Pakistan's Swat Valley, elevated around 2,000 meters. Known for its lush green landscapes and stunning mountain views, it offers popular spots like Ushu Forest and Mahodand Lake for hiking and fishing.",
        imageUrl: "Kalam.jpg"
    },    
    {
        id:(2),
        title: "Naran Kaghan",
        location: "Pakistan",
        googleMapsUrl: "https://maps.app.goo.gl/4YioHoY2N35X6yrn7",
        startDate: "1 July, 2015",
        endDate: "7 July, 2015",
        description: "The beautiful valleys of Naran and Kaghan are situated in the Khyber Pakhtunkhwa province of Pakistan, at an elevation of roughly 2,400 to 3,000 meters. They have breathtaking vistas of verdant meadows and snow-capped hills, and Naran is the entry point to the 3,500-meter-high Saif-ul-Malook Lake.",
        imageUrl: "Naran Kaghan.jpeg"
    },    
    {
        id:(3),
        title: "Mushkpuri Top",
        location: "Pakistan",
        googleMapsUrl: "https://maps.app.goo.gl/BoZadeKHgdaHkxww7",
        startDate: "12 Mar, 2022",
        endDate: "12 Mar, 2022",
        description: "Mushkpuri Top, standing at 2,800 meters, is a renowned trekking peak in Pakistan's Galyat range. It offers stunning panoramic views of the surrounding valleys and mountains, with a rewarding hike starting from Dunga Gali. The trek is celebrated for its natural beauty and the scenic vistas it provides.",
        imageUrl: "Mushkpuri Top.jpeg"
    },    
    {
        id:(4),
        title: "Shogran Siripaye",
        location: "Pakistan",
        googleMapsUrl: "https://goo.gl/maps/1DGM5WrWnATgkSNB8",
        startDate: "17 Dec, 2022",
        endDate: "17 Dec, 2022",
        description: "Shogran and Siripaye are picturesque destinations in Pakistan's Kaghan Valley. Shogran, at an altitude of about 2,300 meters, is known for its lush green meadows and charming cottages. Nearby Siripaye, situated at around 3,000 meters, offers stunning panoramic views of the surrounding peaks and valleys, making it a popular spot for hiking and nature lovers.",
        imageUrl: "Shogran Siripaye.jpeg"
    },

  ];
  