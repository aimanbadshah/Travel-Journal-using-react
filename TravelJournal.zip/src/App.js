import React from 'react';
import './index.css';
import data from './data';
import Trips from './Trips';

export default function App() {
  const trips = data.map(trip => {
    return(
      <Trips className="container"
        key = {trip.id}
        {...trip}
      />
    )
  })
  return (
    <div className='trips-list'>
      {trips}
    </div>
  );
}
